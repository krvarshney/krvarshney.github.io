%FIGURE14   "Sparse Representation in Structured Dictionaries with
%Application to Synthetic Aperture Radar" figure 14.
%   FIGURE14 reproduces figure 14 in the paper "Sparse Representation in
%   Structured Dictionaries with Application to Synthetic Aperture Radar."
%
%   See also FIGURE4, FIGURE789, FIGURE13.

%   Copyright 2006-2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney, M. �etin, J. W. Fisher III, and A. S. Willsky, "Sparse
%   Representation in Structured Dictionaries with Application to Synthetic
%   Aperture Radar," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

N = 400;
G = 8;
theta = linspace(deg2rad(-55),deg2rad(55),N);
[B,M] = molecmatrix(N,'triwhole',G,N/2,N/4);

NFREQ = 3;
FREQ(1).f = 7.04724407196045e9;
FREQ(2).f = 7.05880084662988e9;
FREQ(3).f = 7.07035762129931e9;
c = 299792458;

Phi = [];
for jj = 1:NFREQ
    Phi = [Phi; (exp((-j*4*pi*FREQ(jj).f/c)*(cos(theta') + sin(theta')))*ones(1,M)).*B];
end

I = eye(M);
alpha = 150;
p = .1;

KK = N/2;
KL = 10;

ahatS = zeros(M,KK+KL);

for ii = 1:KK+KL
    disp(ii)
    trues = [zeros(ii-1,1); ones(N-KK-KL+1,1); zeros(KK-ii+KL,1)];
    
    g = [];
    for jj = 1:NFREQ
        g = [g; (exp((-j*4*pi*FREQ(jj).f/c)*(cos(theta') + sin(theta')))).*trues];
    end
    
    ahat = lp_reg2(g,Phi,I,p,alpha);
    ahatS(:,ii) = ahat;
end

%plot
figure;
subplot(2,1,2)
imagesc(1:210,1:36,real(ahatS));
colormap(flipud(gray))
hx = xlabel('column of {\bf g} in molecular graph');
hy = ylabel('coefficient index');
set(gca,'FontName','Times New Roman','FontSize',15,'YTick',[9:9:36],'XTick',[30:30:210]);
set(hx,'FontName','Times New Roman','FontSize',15);
set(hy,'FontName','Times New Roman','FontSize',15);
