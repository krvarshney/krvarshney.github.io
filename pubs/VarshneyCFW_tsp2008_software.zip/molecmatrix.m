function [A,M] = molecmatrix(N,type,m,row,col,inlinefn)
%MOLECMATRIX Amplitude envelope for molecular dictionary matrix.
%   MOLECMATRIX(N,TYPE,Parameter1,...) is a matrix of amplitude scalings
%   [0,1] having N rows for the dictionary specified by TYPE.  
%
%   The possible different dictionaries supported in TYPE are:
%
%         'whole'
%         'halfnhalf'
%         'partwhole'
%         'triwhole'
%         'sggwhole'
%         'spwhole'
%         'triangle'
%         'sggpeaky'
%
%   [A,M] = MOLECMATRIX(N,TYPE,Paramter1,...) returns the matrix in A and
%   the number of columns in M.
%
%   See also HALFNHALFORD, WHOLEORD.

%   Copyright 2005-2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney, M. �etin, J. W. Fisher III, and A. S. Willsky, "Sparse
%   Representation in Structured Dictionaries with Application to Synthetic
%   Aperture Radar," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

switch type
case 'whole'
    A = whole(N);
case 'halfnhalf'
    A = halfnhalf(N);
case 'partwhole'
    A = partwhole(N,m);
case 'triwhole'
    A = triwhole(N,m,row,col);
case 'sggwhole'
    A = sggwhole(N,m,row,col);
case 'spwhole'
    A = spwhole(N);
case 'triangle'
    A = triangle(N);
case 'tritriangle'
    A = tritriangle(N,m,row,col);
case 'sggpeaky'
    A = sggpeaky(N,m,row,col,inlinefn);
otherwise
    error('invalid basis type');
end

M = size(A,2);


function A = whole(N)

A = [ones(N,1) zeros(N,wholeord(N)-1)];

for ii = 1:N-1
    A(:,wholeord(ii)+1:wholeord(ii)+1+ii) = subwhole(N,ii);
end

function t = subwhole(N,ii)

c = [ones(1,N-ii) zeros(1,ii)];
r = [1; zeros(ii,1)];                         % force column structure
p = length(r);
m = length(c);
x = [r(p:-1:2) ; c(:)];                       % build vector of user data
%
cidx = (0:m-1)';
ridx = p:-1:1;
t = cidx(:,ones(p,1)) + ridx(ones(m,1),:);    % Toeplitz subscripts
t(:) = x(t);                                  % actual data

function A = halfnhalf(N)

w = warning;
warning off;

A = [ones(N,1) zeros(N,halfnhalford(N)-1)];
Mii = 1;
for ii = 1:log2(N)
    Aii = subhalfnhalf(N,ii);
    s = size(Aii);
    A(:,Mii+1:Mii+s(2)) = Aii;
    Mii = Mii + s(2);
end
A = A(:,1:Mii);

warning(w);

function t = subhalfnhalf(N,ii)

L = floor(N/(2^ii));

c = [ones(1,L) zeros(1,N-L)];
r = [1; zeros(N-L,1)];                                 % force column structure
p = length(r);
m = length(c);
x = [r(p:-1:2) ; c(:)];                                % build vector of user data
%
cidx = (0:m-1)';
if L>1
    ridx = p:-L/2:1;
else
    ridx = p:-1:1;
end

t = cidx(:,ones(length(ridx),1)) + ridx(ones(m,1),:);  % Toeplitz subscripts
t(:) = x(t);                                           % actual data

function A = partwhole(N,m)

A = zeros(N,sum(m)+length(m));
for ii = 1:length(m)
    A(:,partwholeord(N,m(1:ii))-m(ii):partwholeord(N,m(1:ii))) = subwhole(N,m(ii));
end

function A = triwhole(N,G,row,col)

A = [subtriwhole(N,row,col,row-col) zeros(N,wholeord(G)-1)];

for ii = 1:G-1
    A(:,wholeord(ii)+1:wholeord(ii+1)) = subtriwhole(N,row+ii,col,row-col);
end

function t = subtriwhole(N,ii,left,right)

c = [ones(1,N-ii) zeros(1,ii)];
r = [1; zeros(ii-right,1)];                                 % force column structure
p = length(r);

m = length(c);
x = [r(p:-1:2) ; c(:)];                                     % build vector of user data
%
cidx = (0:m-1)';
ridx = p:-1:1;

t = cidx(:,ones(p-left,1)) + ridx(ones(m,1),1+left:end);    % Toeplitz subscripts
t(:) = x(t);                                                % actual data

function A = sggwhole(N,Ms,row,col)

A = [];
Ms = Ms(:)';
for ii = Ms
    A = [A, subtriwhole(N,row+ii,col,row-col)];
end

function A = spwhole(N)

A = spalloc(N,wholeord(N),nchoosek(N+2,3));
A(:,1) = 1;

for ii = 1:N-1
    A(:,wholeord(ii)+1:wholeord(ii)+1+ii) = subwhole(N,ii);
end

function A = triangle(N)

A = [triang(N) zeros(N,wholeord(N)-1)];

for ii = 1:N-1
    A(:,wholeord(ii)+1:wholeord(ii)+1+ii) = subtriangle(N,ii);
end

function t = subtriangle(N,ii)

c = [triang(N-ii)' zeros(1,ii)];
r = [1; zeros(ii,1)];                         % force column structure
p = length(r);
m = length(c);
x = [r(p:-1:2) ; c(:)];                       % build vector of user data
%
cidx = (0:m-1)';
ridx = p:-1:1;
t = cidx(:,ones(p,1)) + ridx(ones(m,1),:);    % Toeplitz subscripts
t(:) = x(t);                                  % actual data

function A = sggpeaky(N,Ms,row,col,ilf)

A = [];
Ms = Ms(:)';
for ii = Ms
    A = [A, subsggpeaky(N,row+ii,col,row-col,ilf)];
end

function t = subsggpeaky(N,ii,left,right,ilf)

c = [ilf(N-ii) zeros(1,ii)];
r = [1; zeros(ii-right,1)];                                 % force column structure
p = length(r);

m = length(c);
x = [r(p:-1:2) ; c(:)];                                     % build vector of user data
%
cidx = (0:m-1)';
ridx = p:-1:1;

t = cidx(:,ones(p-left,1)) + ridx(ones(m,1),1+left:end);    % Toeplitz subscripts
t(:) = x(t);                                                % actual data
