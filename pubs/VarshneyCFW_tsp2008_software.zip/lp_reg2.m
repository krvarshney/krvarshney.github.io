function xhat = lp_reg2(y,C,L,p,alpha,beta,gamma)
% xhat = lp_reg2(y,C,L,p,alpha,beta,gamma)
%
% y     : Vector of input data
% C     : Corresponding observation operator
% L     : Side constraint operator
% p     : "p" in the Lp norm
% alpha : Regularization parameter
% beta  : Amount of smoothing of the Lp norm.
%         OPTIONAL: Default beta = 1e-5.
% gamma : Stopping criterion
%         OPTIONAL: Default gamma = 1e-3.
%
% xhat  : Estimated field.
%
% solves xhat=argmin( ||y-Cx||_2^2 + alpha*||Lf||_p^p )
%               x
% using a smooth approximation to the Lp norm and half-quadratic regularization.

%   Copyright 2005-2008 M�jdat �etin and Kush R. Varshney
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney, M. �etin, J. W. Fisher III, and A. S. Willsky, "Sparse
%   Representation in Structured Dictionaries with Application to Synthetic
%   Aperture Radar," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

if nargin<6
    beta = 1e-5;
end
if nargin<7
    gamma = 1e-3;
end

% Define these to avoid doing more than once.
Cty = C'*y;
CtC = C'*C;

% Use adjoint for estimate initialization
xhat = Cty;

% Loop until change in estimate is below a given value
err = Inf;
cnt = 1;
while and(err > gamma, cnt < 100)
    tmp = p./((abs(L*xhat).^2) + beta).^(1-p/2);
    Dk = spdiags(tmp,0,length(tmp),length(tmp));

    xhat2=pcg(2*CtC+(alpha)*L'*Dk*L,2*Cty,1e-3,500);
    err = norm(xhat2-xhat,2)/norm(xhat,2);

    xhat = xhat2;
    cnt = cnt+1;
end
