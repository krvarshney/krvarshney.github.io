function M = halfnhalford(N)
%HALFNHALFORD number of columns in 'halfnhalf' dictionary.
%   HALFNHALFORD(N) is the number of columns in the 'halfnhalf' dictionary
%   having N rows.
%
%   See also WHOLEFORD, MOLECMATRIX.

%   Copyright 2005-2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney, M. �etin, J. W. Fisher III, and A. S. Willsky, "Sparse
%   Representation in Structured Dictionaries with Application to Synthetic
%   Aperture Radar," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

M = 3*N - log2(N) - 2;