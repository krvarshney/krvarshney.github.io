function M = wholeord(N)
%WHOLEORD number of columns in 'whole' dictionary.
%   WHOLEORD(N) is the number of columns in the 'whole' dictionary having N
%   rows.
%
%   See also HALFNHALFORD, MOLECMATRIX.

%   Copyright 2005-2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney, M. �etin, J. W. Fisher III, and A. S. Willsky, "Sparse
%   Representation in Structured Dictionaries with Application to Synthetic
%   Aperture Radar," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

M = nchoosek(N+1,2);