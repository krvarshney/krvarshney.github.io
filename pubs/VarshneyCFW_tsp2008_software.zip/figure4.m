%FIGURE4   "Sparse Representation in Structured Dictionaries with
%Application to Synthetic Aperture Radar" figure 4.
%   FIGURE4 reproduces figure 4 in the paper "Sparse Representation in
%   Structured Dictionaries with Application to Synthetic Aperture Radar."
%
%   See also FIGURE789, FIGURE13, FIGURE14.

%   Copyright 2007-2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney, M. �etin, J. W. Fisher III, and A. S. Willsky, "Sparse
%   Representation in Structured Dictionaries with Application to Synthetic
%   Aperture Radar," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

%dictionary
N = 15;
Phi = molecmatrix(N,'whole');

%generate data
a = zeros(wholeord(N),1);
a(99) = 0.8;
a(102) = 1.2;
randn('state',12345); 
g = Phi*a + 0.02*randn(N,1);

%graph-structured algorithm
G = 8;
type = 'triwhole';
I = eye(wholeord(G));
alpha = 0.6;
p = 0.1;
beta = 1e-6;
gamma = 1e-6;

ii = 0;
row = 0;
col = 0;
saverow = 0;
savecol = 0;
continue_flag = 1;
while continue_flag
    saverow(ii+1) = row;
    savecol(ii+1) = col;
    [Phi1,M] = molecmatrix(N,type,G,row,col);
    
    ahat = lp_reg2(g,Phi1,I,p,alpha,beta,gamma);
    continue_flag = 0;
    maximum = max(abs(ahat(wholeord(G-1)+1:M)));
    midx = sum((1:G)'.*abs(ahat(wholeord(G-1)+1:M)))/sum(abs(ahat(wholeord(G-1)+1:M)));
    if maximum > 0.01
        row = row+1;
        if midx > (G+1)/2
            col = col + 1;
        else
        end
        continue_flag = continue_flag + 1;
    end
    ii = ii+1;
end
ig = [];
for jj = 0:G-1
    ig = [ig, wholeord(saverow(end)+jj)+savecol(end)+1:wholeord(saverow(end)+jj)+savecol(end)+1+jj];
end
ahatgs = zeros(wholeord(N),1);
ahatgs(ig) = ahat;

%matching pursuit
ahatmp = zeros(wholeord(N),1);
Phimp = Phi;
gmp = g;
for jj = 1:wholeord(N)
    norms(jj) = norm(Phimp(:,jj));
    Phimp(:,jj) = Phimp(:,jj)/norms(jj);
end
while norm(gmp)>1e-3
    innerprod = Phimp'*gmp;
    [mv,mi]=max(abs(innerprod));
    mv = innerprod(mi);
    mig = mi + sum(find(abs(ahatmp)>0)<mi);
    ahatmp(mig) = mv/norms(mig);
    gmp = gmp - mv*Phimp(:,mi);
    Phimp = [Phimp(:,1:mi-1), Phimp(:,mi+1:end)];
end

%plots
gsa = find(abs(ahatgs)>.1);
mpa = find(abs(ahatmp)>.1);

figure;
subplot(2,3,4);
plot(g,'k');
axis([1 N -0.9 1.4]);
set(gca,'FontName','Times New Roman','FontSize',14,'XTickLabel',[]);

figure;
subplot(2,3,4);
hp = plot(Phi(:,gsa(2))*ahatgs(gsa(2)),'y'); 
set(hp,'Color',[0.5,0.5,0.5]);
hold on;
plot(Phi(:,gsa(1))*ahatgs(gsa(1)),'k'); 
axis([1 N -0.9 1.4]);
set(gca,'FontName','Times New Roman','FontSize',14,'XTickLabel',[]);

figure;
subplot(2,3,4);
hp = plot(Phi(:,mpa(3))*ahatmp(mpa(3)),'y'); 
set(hp,'Color',[0.5,0.5,0.5]);
hold on;
plot(Phi(:,mpa(1))*ahatmp(mpa(1)),'k'); 
plot(Phi(:,mpa(2))*ahatmp(mpa(2)),'k--'); 
axis([1 N -0.9 1.4]);
set(gca,'FontName','Times New Roman','FontSize',14,'XTickLabel',[]);

