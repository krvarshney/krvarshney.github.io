%FIGURE789   "Sparse Representation in Structured Dictionaries with
%Application to Synthetic Aperture Radar" figures 7-9.
%   FIGURE789 reproduces figures 7-9 in the paper "Sparse Representation in
%   Structured Dictionaries with Application to Synthetic Aperture Radar."
%
%   See also FIGURE4, FIGURE13, FIGURE14.

%   Copyright 2006-2008 Kush R. Varshney
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney, M. �etin, J. W. Fisher III, and A. S. Willsky, "Sparse
%   Representation in Structured Dictionaries with Application to Synthetic
%   Aperture Radar," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

%generate data
c = 299792458;

NFREQ = 3;
FREQ(1).f = 7.04724407196045e9;
FREQ(2).f = 7.05880084662988e9;
FREQ(3).f = 7.07035762129931e9;

N = 160;
theta = linspace(deg2rad(-55),deg2rad(55),N);

x = (0:4)';
y = (0:4)';
Lx = length(x);
Ly = length(y);
L = Lx*Ly;
pos = [kron(x,ones(Ly,1)), kron(ones(Lx,1),y)];

NSCAT = 5;

SCATS(1).pos = 7;
SCATS(1).trues = (0.7 + 0.5*j)*[zeros(80,1); ones(72,1); zeros(8,1)];

SCATS(2).pos = 8;
SCATS(2).trues = (0.7 + 0.4*j)*[zeros(79,1); ones(60,1); zeros(21,1)];

SCATS(3).pos = 11;
SCATS(3).trues = (0.6 + 0.8*j)*[ones(140,1); zeros(20,1)];

SCATS(4).pos = 19;
SCATS(4).trues = (0.4 + 0.4*j)*[ones(160,1)];

SCATS(5).pos = 22;
SCATS(5).trues = (0.7 + 1.3*j)*[zeros(90,1); ones(30,1); zeros(40,1)];

for ii = 1:NSCAT
    SCATS(ii).x = pos(SCATS(ii).pos,1);
    SCATS(ii).y = pos(SCATS(ii).pos,2);
end

g = zeros(NFREQ*N,1);
for ii = 1:NSCAT
    gs = [];
    for jj = 1:NFREQ
        gs = [gs; (exp((-j*4*pi*FREQ(jj).f/c)*(SCATS(ii).x*cos(theta') + SCATS(ii).y*sin(theta')))).*SCATS(ii).trues];
    end
    g = g + gs;
end

%graph-structured algorithm
G = 8;
type = 'triwhole';
I = speye(wholeord(G)*L);
alpha = 12;
p = .1;

ii = 0;
row = zeros(1,L);
col = zeros(1,L);
saverow = zeros(1,L);
savecol = zeros(1,L);
continue_flag = 1;
while continue_flag
    saverow(ii+1,:) = row;
    savecol(ii+1,:) = col;
    Phi = [];
    for ll = 1:L
        Phill = [];
        [B,M] = molecmatrix(N,type,G,row(ll),col(ll));
        for jj = 1:NFREQ
            Phill = [Phill; (exp((-j*4*pi*FREQ(jj).f/c)*(pos(ll,1)*cos(theta') + pos(ll,2)*sin(theta')))*ones(1,M)).*B];
        end
        Phi = [Phi Phill];
    end

    ahat = lp_reg2(g,Phi,I,p,alpha);
    continue_flag = 0;
    for ll = 1:L
        maximum = max(abs(ahat(M*(ll-1)+wholeord(G-1)+1:M*ll)));
        midx = sum((1:G)'.*abs(ahat(M*(ll-1)+wholeord(G-1)+1:M*ll)))/sum(abs(ahat(M*(ll-1)+wholeord(G-1)+1:M*ll)));
        if maximum > 0.01
            row(ll) = row(ll)+1;
            if midx > G/2
                col(ll) = col(ll) + 1;
            else
            end
            continue_flag = continue_flag + 1;
        end
    end
    ii = ii+1
end

%plots
subplotorder = reshape(1:L,Ly,Lx)';

figure;
for ll = 1:L
    subplot(Ly,Lx,subplotorder(ll));
    hold on;
    plot(rad2deg(theta),abs(Phi(1:N,(ll-1)*M+1:ll*M)*ahat((ll-1)*M+1:ll*M)),'k-')
    kk = find(ll == [7 8 11 19 22]);
    if kk
        plot(rad2deg(theta),abs(SCATS(kk).trues),'k:');
    else
        plot(rad2deg(theta),zeros(N,1),'k:');
    end
    hx = xlabel('\theta');
    set(gca,'YTick',[0 1],'FontName','Times New Roman','FontSize',15);
    set(hx,'FontName','Times New Roman','FontSize',15);
    set(gca,'XTick',[])
    axis([-55 55 -.1 1.6])
end

figure;
t = [0, 0; -N+1, -N+1; N-1, -N+1; 0, 0];
for ll = 1:L
    subplot(Ly,Lx,subplotorder(ll));
    hold on;
    h1 = plot(t(:,1),t(:,2),'k-');
    h2 = plot(2*savecol(:,ll)-saverow(:,ll),-saverow(:,ll),'k-');
    set(h2,'LineWidth',3);
    axis off
end

figure;
subplot(3,1,3);
ghat = Phi*ahat;
plot(rad2deg(theta),abs(g(1:N)),'k:',rad2deg(theta),abs(ghat(1:N)),'k-');
hx = xlabel('\theta (degrees)');
hy = ylabel('|g(\theta)|');
axis([-55 55 0 4.5]);
set(gca,'FontName','Times New Roman','FontSize',15);
set(hx,'FontName','Times New Roman','FontSize',15);
set(hy,'FontName','Times New Roman','FontSize',15);
