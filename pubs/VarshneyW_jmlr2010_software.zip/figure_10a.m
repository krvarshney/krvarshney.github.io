%FIGURE_10A "Classification Using Geometric Level Sets" Figure 10a.
%   FIGURE_10A reproduces Figure 10a in the paper "Classification Using
%   Geometric Level Sets."

%   Copyright 2010 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and A. S. Willsky, "Classification Using Geometric Level
%   Sets," Journal of Machine Learning Research, 2010.
%
%   Available at http://ssg.mit.edu/~krv.

loss = @(z) log(1+exp(-z)); %logistic
numfolds = 10;
lambdav = [0.1 0.2 0.4 0.8 1.6 3.2 6.4];
trainingerror = zeros(numfolds,length(lambdav));
testerror = zeros(numfolds,length(lambdav));

for ff = 1:numfolds
    load pima_norm
    xtrain = x(:,setdiff(1:end,ff:numfolds:end));
    ytrain = y(setdiff(1:end,ff:numfolds:end));
    xtest = x(:,ff:numfolds:end);
    ytest = y(ff:numfolds:end);
    for ll = 1:length(lambdav)
        [alpha,trainingerror(ff,ll)] = glstrain(xtrain,ytrain,loss,lambdav(ll));
        testerror(ff,ll) = sum(glsclassify(xtrain,alpha,xtest)~=ytest(:))/length(ytest);
    end
end

figure;
hp = semilogx(lambdav,mean(trainingerror),'b^-',lambdav,mean(testerror),'ro-');
set(hp,'LineWidth',2);
ylabel('classification error','FontName','Times New Roman','FontSize',22);
xlabel('\lambda','FontName','Times New Roman','FontSize',22);
set(gca,'XTick',lambdav,'FontName','Times New Roman','FontSize',17);
axis([.064 10 0 .35]);
