function y = cauchypdf(x,epsilon)
%CAUCHYPDF Cauchy probability density function.
%   Y = CAUCHYPDF(X,EPSILON) returns the Cauchy probability density
%   function with parameter EPSILON at the values in X.
%
%   The size of Y is the common size of the input arguments. A scalar input
%   functions as a constant matrix of the same size as the other inputs.

%   Copyright 2010 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and A. S. Willsky, "Classification Using Geometric Level
%   Sets," Journal of Machine Learning Research, 2010.
%
%   Available at http://ssg.mit.edu/~krv.

y = epsilon./(pi*(epsilon.^2 + x.^2));
