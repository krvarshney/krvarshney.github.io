%GLASS_IDENTIFICATION_EXAMPLE runs the GLS classifier on a multiclass example.
%   GLASS_IDENTIFICATION_EXAMPLE provides an example of running the
%   geometric level set classifier on the glass identification data set, a
%   multicategory data set from the UCI Machine Learning Repository.

%   Copyright 2010 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and A. S. Willsky, "Classification Using Geometric Level
%   Sets," Journal of Machine Learning Research, 2010.
%
%   Available at http://ssg.mit.edu/~krv.

loss = @(z) log(1+exp(-z)); %logistic
numfolds = 10;
trainingerror = zeros(numfolds,1);
testerror = zeros(numfolds,1);

for ff = 1:numfolds
    load glass_norm
    xtrain = x(:,setdiff(1:end,ff:numfolds:end));
    ytrain = y(setdiff(1:end,ff:numfolds:end));
    xtest = x(:,ff:numfolds:end);
    ytest = y(ff:numfolds:end);

    [alpha,trainingerror(ff)] = glstrain(xtrain,ytrain,loss);
    testerror(ff) = sum(glsclassify(xtrain,alpha,xtest)~=ytest(:))/length(ytest);
end
disp(mean(testerror));
