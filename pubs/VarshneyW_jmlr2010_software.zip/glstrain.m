function [alpha,trainingerror] = glstrain(x,y,loss,lambda,numiters)
%GLSTRAIN trains a geometric level set classifier.
%   [ALPHA,TRAININGERROR] = GLSTRAIN(X,Y,LOSS) trains a geometric level set
%   classifier using data X taken from groups given by Y using the
%   margin-based loss function LOSS.  ALPHA is the vector of coefficients
%   for the radial basis functions that is learned with error equal to
%   TRAININGERROR.  For binary problems, Y should be a row vector of values
%   {+1,-1} of the same length as X.  For M class problems with M > 2, Y
%   should take values {1,2,...,M}.  The data in X should be scaled and
%   shifted so that each dimension has approximately unit variance and zero
%   mean.
%   
%   GLSTRAIN(...,LAMBDA) additionally sets the regularization weight given
%   to the surface area regularization term.  The default value if not
%   specified is 0.5.
%
%   GLSTRAIN(...,NUMITERS) additionally sets the number of iterations of
%   contour evolution that are performed.  The default value if not
%   specified is 50.
%
%   See also CLASSIFY, CLASSPERF, CROSSVALIND, KNNCLASSIFY, SVMCLASSIFY,
%   GLSCLASSIFY.

%   Copyright 2010 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and A. S. Willsky, "Classification Using Geometric Level
%   Sets," Journal of Machine Learning Research, 2010.
%
%   Available at http://ssg.mit.edu/~krv.

if nargin < 4
    lambda = 0.5;
end
if nargin < 5
    numiters = 50;
end

D = size(x,1);
if max(y)<2
    m = 1;
else
    m = ceil(log2(max(y)));
end
n = length(y);

epsilon = 20;

if m == 1
    plusminus = y(:); 
else
    plusminus = zeros(n,m);
    for jj = 1:m
        plusminus(:,jj) = (-1).^mod(ceil(y(:)/(2^(m-jj))),2);
    end
end

xdiff = zeros(D,n,n);
for ii = 1:n
    for jj = 1:n
        xdiff(:,ii,jj) = x(:,ii) - x(:,jj);
    end
end

H = zeros(n,n);
for ii = 1:n
    for jj = ii:n
        H(ii,jj) = exp(-norm(xdiff(:,ii,jj))^2);
        H(jj,ii) = H(ii,jj);
    end
end

invH = pinv(H);

alpha = zeros(n,m);
for jj = 1:m
    alpha(:,jj) = invH*plusminus(:,jj);
    alpha(:,jj) = n*alpha(:,jj)/norm(alpha(:,jj),1);
end

tau = 1/m;
for tt = 1:numiters
    if m == 1
        psi = y(:).*(H*alpha(:,1));
    else
        psi = -plusminus(:,1).*(H*alpha(:,1));
        for jj = 2:m
            psi = max(psi,-plusminus(:,jj).*(H*alpha(:,jj)));
        end
    end
    for jj = 1:m
         alpha(:,jj) = alpha(:,jj) - tau*invH*((sign(H*alpha(:,jj)).*loss(psi) + (lambda/m)*meancurvature(alpha(:,jj),1,H,xdiff)).*cauchypdf(H*alpha(:,jj),epsilon));
         alpha(:,jj) = n*alpha(:,jj)/norm(alpha(:,jj),1);
    end
end

if m == 1
    yhat = sign(H*alpha);
else
    yhat = zeros(n,1);
    for jj = 1:m
        onezero = (sign(H*alpha(:,jj))+1)/2;
        yhat = yhat + onezero*(2^(m-jj));
    end
    yhat = yhat + 1;
end

trainingerror = sum(yhat(:)~=y(:))/n;
