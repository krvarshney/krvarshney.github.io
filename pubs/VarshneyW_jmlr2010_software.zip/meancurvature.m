function [kappa,gradphi] = meancurvature(alpha,beta,H,xdiff)
%MEANCURVATURE Mean curvature and gradient of level set function.
%   [KAPPA,GRADPHI] = MEANCURVATURE(ALPHA,BETA,H,XDIFF) returns the mean
%   curvature KAPPA and gradient vector GRADPHI of the level set function
%   phi(x) defined as the linear combination of Gaussian radial basis
%   functions with coefficient vector ALPHA, scale parameter BETA, pairwise
%   differences of function centers XDIFF, and Gram matrix H with elements
%   containing the norm squared of the pairwise differences applied as the
%   argument to the radial basis function.

%   Copyright 2010 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and A. S. Willsky, "Classification Using Geometric Level
%   Sets," Journal of Machine Learning Research, 2010.
%
%   Available at http://ssg.mit.edu/~krv.

[D,n,scrap] = size(xdiff);

gradphi = zeros(D,n);
for dd = 1:D
    gradphi(dd,:) = 2*beta*(H.*squeeze(xdiff(dd,:,:)))*alpha;
end

Hessian = zeros(D,D,n);
for d1 = 1:D
    for d2 = d1:D
        if d1 ~= d2
            Hessian(d1,d2,:) = 4*beta^2*(H.*squeeze(xdiff(d1,:,:)).*squeeze(xdiff(d2,:,:)))*alpha;
            Hessian(d2,d1,:) = Hessian(d1,d2,:);
        else
            Hessian(d1,d2,:) = ((4*beta^2*squeeze(xdiff(d1,:,:)).^2 - 2*beta).*H)*alpha;
        end
    end
end

kappa = zeros(n,1);
for ii = 1:n
    normgradphi = norm(gradphi(:,ii));
    if D == 1
        kappa(ii) = Hessian(1,1,ii)/normgradphi;
    else
        kappa(ii) = (gradphi(:,ii)'*Hessian(:,:,ii)*gradphi(:,ii) - normgradphi^2*trace(Hessian(:,:,ii)))/(normgradphi*(D-1));
    end
end
