function yhat = glsclassify(centers,alpha,x)
%GLSCLASSIFY classifies data using a geometric level set classifier.
%   YHAT = GLSCLASSIFY(CENTERS,ALPHA,X) classifies the data in X using the
%   information in a geometric level set classifier ALPHA vector produced
%   by GLSTRAIN with radial basis function centers given in CENTERS.  For
%   binary problems, YHAT is a vector of values {+1,-1} of the same length
%   as X.  For M class problems with M > 2, YHAT takes values {1,2,...,M}.
%
%   See also CLASSIFY, CLASSPERF, CROSSVALIND, KNNCLASSIFY, SVMCLASSIFY,
%   GLSTRAIN.

%   Copyright 2010 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and A. S. Willsky, "Classification Using Geometric Level
%   Sets," Journal of Machine Learning Research, 2010.
%
%   Available at http://ssg.mit.edu/~krv.

n1 = size(centers,2);
n2 = size(x,2);
m = size(alpha,2);

H = zeros(n2,n1);
for ii = 1:n2
    for jj = 1:n1
        H(ii,jj) = exp(-norm(x(:,ii)-centers(:,jj))^2);
    end
end

if m == 1
    yhat = sign(H*alpha);
else
    yhat = zeros(n2,1);
    for jj = 1:m
        onezero = (sign(H*alpha(:,jj))+1)/2;
        yhat = yhat + onezero*(2^(m-jj));
    end
    yhat = yhat + 1;
end
