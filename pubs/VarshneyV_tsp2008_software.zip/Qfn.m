function Q = Qfn(a)
%QFN  Q function.
%   QFN(A) is the Q function of A.  A must be real.  The Q function is the 
%   complementary cumulative distribution function for the Gaussian random
%   variable.
%
%   Class support for input A:
%      float: double, single
%
%   See also ERF, ERFC, ERFCX, ERFINV, ERFCINV.

%   Copyright 2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and L. R. Varshney, "Quantization of Prior Probabilities
%   for Hypothesis Testing," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

Q = erfc(a/sqrt(2))/2;
