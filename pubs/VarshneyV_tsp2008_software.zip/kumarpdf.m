function y = kumarpdf(x,a,b)
%KUMARPDF Kumaraswamy probability density function.
%   Y = KUMARPDF(X,A,B) returns the Kumaraswamy probability density
%   function with parameters A and B at the values in X.
%
%   The size of Y is the common size of the input arguments. A scalar input
%   functions as a constant matrix of the same size as the other inputs.
%
%   See also KUMARCDF, KUMARINV.

%   Copyright 2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and L. R. Varshney, "Quantization of Prior Probabilities
%   for Hypothesis Testing," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

if a <= 0
   error('a must be > 0');
end
if b <= 0
   error('b must be > 0');
end

y = a.*b.*x.^(a-1).*(1-x.^a).^(b-1);
