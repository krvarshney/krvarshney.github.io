function [a,b,D] = lloydmax(K,mu,sigma,c10,c01,distortion,distribution,varargin)
%LLOYDMAX Lloyd-Max Algorithm for quantizer design.
%   [A,B] =
%   LLOYDMAX(K,MU,SIGMA,C10,C01,DISTORTION,DISTRIBUTION,DistributionParamet
%   er1,...) designs a K-point scalar quantizer for prior probabilities in
%   a Bayesian hypothesis test using the Lloyd-Max algorithm, returning the 
%   representation points of the quantizer in A and the boundary points of
%   the quantizer in B.  The measurement model is additive Gaussian noise
%   with standard deviation SIGMA.  One of the hypotheses has mean zero and
%   the other hypothesis has mean MU.  The Bayes costs are C10 and C01.
%   The input DISTORTION, either 'mae' or 'mbre', specifies which
%   distortion to optimize the quantizer for: absolute error or Bayes risk
%   error.  The input DISTRIBUTION and DistributionParameters specify the
%   probability law governing the prior probabilities.  Currently, the Beta
%   distribution specified using 'beta' and the Kumaraswamy distribution
%   specified using 'kumar' are supported.  Both distributions take two
%   positive parameters.  
%
%   [A,B,D] =
%   LLOYDMAX(K,MU,SIGMA,C10,C01,DISTORTION,DISTRIBUTION,DistributionParamet
%   er1,...) also gives the mean Bayes risk error of the quantizer.
%
%   See also HIGHRATE, PE1, PE2.

%   Copyright 2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and L. R. Varshney, "Quantization of Prior Probabilities
%   for Hypothesis Testing," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.
%   Copyright 2008 Kush R. Varshney 

%   Related article:
%   K. R. Varshney and L. R. Varshney, "Quantization of Prior Probabilities
%   for Hypothesis Testing," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

switch distribution
    case {'beta','kumar'}
        alpha = varargin{1};
        beta = varargin{2};
    otherwise
        error('unsupported distribution');
end

a = 1/(2*K):1/K:(2*K-1)/(2*K);
EJtildeold = Inf;
deltaEJtilde = Inf;

iter = 1;
while or(deltaEJtilde>1e-8, iter<20)
    %nearest neighbor condition
    switch distortion
        case 'mae'
            b = [0, (a(1:end-1)+a(2:end))/2, 1];
        case 'mbre'
            pe1v = pe1(a,mu,sigma,c10,c01); pe1diff = diff(pe1v);
            pe2v = pe2(a,mu,sigma,c10,c01); pe2diff = diff(pe2v);
            b = [0, c01*pe2diff./(c01*pe2diff - c10*pe1diff), 1];
        otherwise
            error('unsupported distortion');
    end

    %centroid condition
    EJtilde = 0;
    for jj = 1:K
        I1 = quad(@(p0)p0fP0(p0,distribution,alpha,beta),b(jj),b(jj+1));
        I2 = quad(@(p0)omp0fP0(p0,distribution,alpha,beta),b(jj),b(jj+1));
        
        switch distortion
            case 'mae'
                switch distribution
                    case 'beta'
                        a(jj) = betainv((betacdf(b(jj),alpha,beta)+betacdf(b(jj+1),alpha,beta))/2,alpha,beta);
                    case 'kumar'
                        a(jj) = kumarinv((kumarcdf(b(jj),alpha,beta)+kumarcdf(b(jj+1),alpha,beta))/2,alpha,beta);
                end
            case 'mbre'
                a(jj) = I1/(I1+I2);
        end
        EJtilde = EJtilde + c10*I1*pe1(a(jj),mu,sigma,c10,c01) + c01*I2*pe2(a(jj),mu,sigma,c10,c01);
    end
    deltaEJtilde = EJtildeold-EJtilde;
    EJtildeold = EJtilde;
    iter = iter+1;
end

EJ = quad(@(p0)JfP0(p0,mu,sigma,c10,c01,distribution,alpha,beta),0,1);
D = EJtilde - EJ;

function val = JfP0(p0,mu,sigma,c10,c01,distribution,varargin)

switch distribution
    case 'beta'
        alpha = varargin{1};
        beta = varargin{2};
        val = betapdf(p0,alpha,beta).*(c10.*p0.*pe1(p0,mu,sigma,c10,c01) + c01.*(1-p0).*pe2(p0,mu,sigma,c10,c01));
    case 'kumar'
        alpha = varargin{1};
        beta = varargin{2};
        val = kumarpdf(p0,alpha,beta).*(c10.*p0.*pe1(p0,mu,sigma,c10,c01) + c01.*(1-p0).*pe2(p0,mu,sigma,c10,c01));        
    otherwise
        error('unsupported distribution');
end

function val = p0fP0(p0,distribution,varargin)

switch distribution
    case 'beta'
        alpha = varargin{1};
        beta = varargin{2};
        val = p0.*betapdf(p0,alpha,beta);
    case 'kumar'
        alpha = varargin{1};
        beta = varargin{2};
        val = p0.*kumarpdf(p0,alpha,beta);
    otherwise
        error('unsupported distribution');
end

function val = omp0fP0(p0,distribution,varargin)

switch distribution
    case 'beta'
        alpha = varargin{1};
        beta = varargin{2};
        val = (1-p0).*betapdf(p0,alpha,beta);
    case 'kumar'
        alpha = varargin{1};
        beta = varargin{2};
        val = (1-p0).*kumarpdf(p0,alpha,beta);
    otherwise
        error('unsupported distribution');
end
