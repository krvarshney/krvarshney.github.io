function [lambda,D] = highrate(K,p0,mu,sigma,c10,c01,distortion,distribution,varargin)
%HIGHRATE High-rate quantizer.
%   HIGHRATE(K,P0,MU,SIGMA,C10,C01,DISTORTION,DISTRIBUTION,DistributionPara
%   meter1,...) gives the quantizer point density for prior probabilities
%   in a Bayesian hypothesis test evaluated at the points in P0.  The
%   measurement model is additive Gaussian noise with standard deviation
%   SIGMA.  One of the hypotheses has mean zero and the other hypothesis
%   has mean MU.  The Bayes costs are C10 and C01.  The input DISTORTION,
%   either 'mae' or 'mbre', specifies which distortion to optimize the
%   quantizer for: absolute error or Bayes risk error.  The input
%   DISTRIBUTION and DistributionParameters specify the probability law
%   governing the prior probabilities.  Currently, the Beta distribution
%   specified using 'beta' and the Kumaraswamy distribution specified using
%   'kumar' are supported.  Both distributions take two positive
%   parameters.  
%   
%   [LAMBDA,D] =
%   HIGHRATE(K,P0,MU,SIGMA,C10,C01,DISTORTION,DISTRIBUTION,DistributionPara
%   meter1,...) also returns the high-rate approximation to the mean Bayes
%   risk error of the K-point quantizer.  K can be a vector.
%
%   See also LLOYDMAX, PE1, PE2.

%   Copyright 2008 Kush R. Varshney
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and L. R. Varshney, "Quantization of Prior Probabilities
%   for Hypothesis Testing," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

switch distribution
    case {'beta','kumar'}
        alpha = varargin{1};
        beta = varargin{2};
    otherwise
        error('unsupported distribution');
end

switch distortion
    case 'mae'
        Lpnorm2 = quad(@(p0)fP0_to_onehalf(p0,distribution,alpha,beta),0,1)^2;
        intB = quad(@(p0)B(p0,mu,sigma,c10,c01),0,1);
        D = Lpnorm2*intB./(12*K.^2);
        lambda = fP0_to_onehalf(p0,distribution,alpha,beta)/sqrt(Lpnorm2);
    case 'mbre'
        Lpnorm3 = quad(@(p0)BfP0_to_onethird(p0,mu,sigma,c10,c01,distribution,alpha,beta),0,1)^3;
        D = Lpnorm3./(12*K.^2);
        lambda = BfP0_to_onethird(p0,mu,sigma,c10,c01,distribution,alpha,beta)/Lpnorm3^(1/3);
    otherwise
        error('unsupported distortion');
end

function val = fP0_to_onehalf(p0,distribution,varargin)

switch distribution
    case 'beta'
        alpha = varargin{1};
        beta = varargin{2};
        val = betapdf(p0,alpha,beta).^(1/2);
    case 'kumar'
        alpha = varargin{1};
        beta = varargin{2};
        val = kumarpdf(p0,alpha,beta).^(1/2);
    otherwise
        error('unsupported distribution');
end

function val = BfP0_to_onethird(p0,mu,sigma,c10,c01,distribution,varargin)

switch distribution
    case 'beta'
        alpha = varargin{1};
        beta = varargin{2};
        val = (B(p0,mu,sigma,c10,c01).*betapdf(p0,alpha,beta)).^(1/3);
    case 'kumar'
        alpha = varargin{1};
        beta = varargin{2};
        val = (B(p0,mu,sigma,c10,c01).*kumarpdf(p0,alpha,beta)).^(1/3);
    otherwise
        error('unsupported distribution');
end

function val = B(p0,mu,sigma,c10,c01)

val = 1/2*d2bre(p0,mu,sigma,c10,c01);

function d2d = d2bre(p0,mu,sigma,c10,c01)

d2d = -c10*p0.*d2pe1(p0,mu,sigma,c10,c01) - 2*c10*dpe1(p0,mu,sigma,c10,c01) - c01*(1-p0).*d2pe2(p0,mu,sigma,c10,c01) + 2*c01*dpe2(p0,mu,sigma,c10,c01);

function dpe = dpe1(a,mu,sigma,c10,c01)

dpe = -1/sqrt(2*pi) * sigma/mu * 1./(a.*(1-a)) .* exp(-1/2 * (mu/(2*sigma) + sigma/mu * log(c10*a./(c01*(1-a)))).^2);

function dpe = dpe2(a,mu,sigma,c10,c01)

dpe = 1/sqrt(2*pi) * sigma/mu * 1./(a.*(1-a)) .* exp(-1/2 * (mu/(2*sigma) - sigma/mu * log(c10*a./(c01*(1-a)))).^2);

function d2pe = d2pe1(a,mu,sigma,c10,c01)

d2pe = -1/sqrt(8*pi) * sigma/mu * 1./(a.^2.*(1-a).^2) .* exp(-(mu^2 + 2*sigma^2*log(c10*a./(c01*(1-a)))).^2/(8*sigma^2*mu^2)) .* (-3 + 4*a - 2*sigma^2/mu^2*log(c10*a./(c01*(1-a))));

function d2pe = d2pe2(a,mu,sigma,c10,c01)

d2pe = +1/sqrt(8*pi) * sigma/mu * 1./(a.^2.*(1-a).^2) .* exp(-(mu^2 - 2*sigma^2*log(c10*a./(c01*(1-a)))).^2/(8*sigma^2*mu^2)) .* (-1 + 4*a - 2*sigma^2/mu^2*log(c10*a./(c01*(1-a))));

