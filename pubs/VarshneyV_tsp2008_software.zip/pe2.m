function pe = pe2(a,mu,sigma,c10,c01)
%PE2  Type II error probability.
%   PE2(A,MU,SIGMA,C10,C01) is the Type II error probability for a Bayesian 
%   hypothesis test with prior probability A where the measurement model is
%   additive Gaussian noise with standard deviation SIGMA.  One of the 
%   hypotheses has mean zero and the other hypothesis has mean MU.  The 
%   Bayes costs are C10 and C01.
%
%   See also PE1, LLOYDMAX, HIGHRATE.

%   Copyright 2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and L. R. Varshney, "Quantization of Prior Probabilities
%   for Hypothesis Testing," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

a(a<0) = 0; a(a>1) = 1;
pe = Qfn(mu/(2*sigma) - sigma/mu*log(c10*a./(c01*(1-a))));

