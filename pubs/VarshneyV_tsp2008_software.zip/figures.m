%FIGURES   "Quantization of Prior Probabilities for Hypothesis Testing" figures.
%   FIGURES reproduces the figures in the paper "Quantization of Prior
%   Probabilities for Hypothesis Testing."

%   Copyright 2008 Kush R. Varshney 
%
%   This software is provided without warranty.

%   Related article:
%   K. R. Varshney and L. R. Varshney, "Quantization of Prior Probabilities
%   for Hypothesis Testing," IEEE Transactions on Signal Processing, 2008.
%
%   Available at http://ssg.mit.edu/~krv.

%Examples with additive Gaussian noise measurement model
mu = 1;
sigma = 1;

%Uniformly Distributed P0, equal Bayes costs
distribution = 'beta';
alpha = 1;
beta = 1;
c10 = 1;
c01 = 1;

p0 = linspace(0,1,500);
J = c10.*p0.*pe1(p0,mu,sigma,c10,c01) + c01.*(1-p0).*pe2(p0,mu,sigma,c10,c01);

%low-rate quantization
KK = 9;
D_mae = zeros(KK,1);
D_mbre = zeros(KK,1);
amae = cell(KK,1);
bmae = cell(KK,1);
ambre = cell(KK,1);
bmbre = cell(KK,1);
for K = 1:KK
    [amae{K},bmae{K},D_mae(K)] = lloydmax(K,mu,sigma,c10,c01,'mae',distribution,alpha,beta);
    [ambre{K},bmbre{K},D_mbre(K)] = lloydmax(K,mu,sigma,c10,c01,'mbre',distribution,alpha,beta);
end

%high-rate quantization
R = linspace(0,5);
K = 2.^R;
[scrap,Dmae] = highrate(K,p0,mu,sigma,c10,c01,'mae',distribution,alpha,beta);
[lambda,Dmbre] = highrate(K,p0,mu,sigma,c10,c01,'mbre',distribution,alpha,beta);

%Figure 2
figure;
hp = semilogy(1:KK,D_mae,'k*:',1:KK,D_mbre,'ko-');
hx = xlabel('$K$','Interpreter','latex','FontSize',28);
hy = ylabel('$D$','Interpreter','latex','FontSize',28);
set(gca,'FontName','Times New Roman','FontSize',28);
set(hp,'MarkerSize',18);
axis([0 9 .0008 .15]);

%Figure 3
figure;
semilogy(R,Dmbre,'k-',R,Dmae,'k:');
ylabel('$D$','Interpreter','latex','FontSize',28);
xlabel('$R$ (bits)','Interpreter','latex','FontSize',28);
set(gca,'FontSize',28,'FontName','Times New Roman');

%Figure 4
KK = 4;
for K = 1:KK
    figure; 
    hp = plot(p0,J,'k');
    set(hp,'LineWidth',1.5,'Color',[0.5 0.5 0.5]);
    hold on;
    
    a = amae{K};
    b = bmae{K};
    for jj = 1:K
        p0t = [b(jj),b(jj+1)];
        Jtilde = c10*p0t.*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-p0t).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj)))));
        hp = plot(p0t,Jtilde,'k:',a(jj),c10*a(jj).*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-a(jj)).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))),'k*');
        set(hp,'LineWidth',1.5,'MarkerSize',36);
    end
    
    a = ambre{K};
    b = bmbre{K};
    for jj = 1:K
        p0t = [b(jj),b(jj+1)];
        Jtilde = c10*p0t.*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-p0t).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj)))));
        hp = plot(p0t,Jtilde,'k-',a(jj),c10*a(jj).*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-a(jj)).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))),'ko');
        set(hp,'LineWidth',1.5,'MarkerSize',36);
    end
    hx = xlabel('$p_0$','Interpreter','latex','FontSize',56);
    hy = ylabel('$\tilde{J}(p_0,v(p_0))$','Interpreter','latex','FontSize',56);
    set(gca,'FontName','Times New Roman','FontSize',56);
end

%Figure 5
figure;
plot(p0,lambda,'k');
xlabel('$p_0$','Interpreter','latex','FontSize',28);
ylabel('$\lambda(p_0)$','Interpreter','latex','FontSize',28);
set(gca,'FontSize',28,'FontName','Times New Roman');

%Uniformly Distributed P0, unequal Bayes costs
distribution = 'beta';
alpha = 1;
beta = 1;
c10 = 1;
c01 = 4;

%low-rate quantization
KK = 9;
D_mae = zeros(KK,1);
D_mbre = zeros(KK,1);
amae = cell(KK,1);
bmae = cell(KK,1);
ambre = cell(KK,1);
bmbre = cell(KK,1);
for K = 1:KK
    [amae{K},bmae{K},D_mae(K)] = lloydmax(K,mu,sigma,c10,c01,'mae',distribution,alpha,beta);
    [ambre{K},bmbre{K},D_mbre(K)] = lloydmax(K,mu,sigma,c10,c01,'mbre',distribution,alpha,beta);
end

p0 = linspace(0,1,500);
J = c10.*p0.*pe1(p0,mu,sigma,c10,c01) + c01.*(1-p0).*pe2(p0,mu,sigma,c10,c01);

%high-rate quantization
R = linspace(0,5);
K = 2.^R;
[scrap,Dmae] = highrate(K,p0,mu,sigma,c10,c01,'mae',distribution,alpha,beta);
[lambda,Dmbre] = highrate(K,p0,mu,sigma,c10,c01,'mbre',distribution,alpha,beta);

%Figure 6
figure;
hp = semilogy(1:KK,D_mae,'k*:',1:KK,D_mbre,'ko-');
hx = xlabel('$K$','Interpreter','latex','FontSize',28);
hy = ylabel('$D$','Interpreter','latex','FontSize',28);
set(gca,'FontName','Times New Roman','FontSize',28);
set(hp,'MarkerSize',18);
axis([0 9 .001 .2]);

%Figure 7
figure;
semilogy(R,Dmbre,'k-',R,Dmae,'k:');
ylabel('$D$','Interpreter','latex','FontSize',28);
xlabel('$R$ (bits)','Interpreter','latex','FontSize',28);
set(gca,'FontSize',28,'FontName','Times New Roman');

%Figure 8
KK = 4;
for K = 1:KK
    figure; 
    hp = plot(p0,J,'k');
    set(hp,'LineWidth',1.5,'Color',[0.5 0.5 0.5]);
    hold on;
    
    a = amae{K};
    b = bmae{K};
    for jj = 1:K
        p0t = [b(jj),b(jj+1)];
        Jtilde = c10*p0t.*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-p0t).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj)))));
        hp = plot(p0t,Jtilde,'k:',a(jj),c10*a(jj).*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-a(jj)).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))),'k*');
        set(hp,'LineWidth',1.5,'MarkerSize',36);
    end
    
    a = ambre{K};
    b = bmbre{K};
    for jj = 1:K
        p0t = [b(jj),b(jj+1)];
        Jtilde = c10*p0t.*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-p0t).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj)))));
        hp = plot(p0t,Jtilde,'k-',a(jj),c10*a(jj).*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-a(jj)).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))),'ko');
        set(hp,'LineWidth',1.5,'MarkerSize',36);
    end
    hx = xlabel('$p_0$','Interpreter','latex','FontSize',56);
    hy = ylabel('$\tilde{J}(p_0,v(p_0))$','Interpreter','latex','FontSize',56);
    set(gca,'FontName','Times New Roman','FontSize',56);
end

%Figure 9
figure;
plot(p0,lambda,'k');
xlabel('$p_0$','Interpreter','latex','FontSize',28);
ylabel('$\lambda(p_0)$','Interpreter','latex','FontSize',28);
set(gca,'FontSize',28,'FontName','Times New Roman');

%Beta(5,2) Distributed P0, equal Bayes costs
distribution = 'beta';
alpha = 5;
beta = 2;
c10 = 1;
c01 = 1;

%low-rate quantization
KK = 9;
D_mae = zeros(KK,1);
D_mbre = zeros(KK,1);
amae = cell(KK,1);
bmae = cell(KK,1);
ambre = cell(KK,1);
bmbre = cell(KK,1);
for K = 1:KK
    [amae{K},bmae{K},D_mae(K)] = lloydmax(K,mu,sigma,c10,c01,'mae',distribution,alpha,beta);
    [ambre{K},bmbre{K},D_mbre(K)] = lloydmax(K,mu,sigma,c10,c01,'mbre',distribution,alpha,beta);
end

p0 = linspace(0,1,500);
J = c10.*p0.*pe1(p0,mu,sigma,c10,c01) + c01.*(1-p0).*pe2(p0,mu,sigma,c10,c01);

%high-rate quantization
R = linspace(0,5);
K = 2.^R;
[scrap,Dmae] = highrate(K,p0,mu,sigma,c10,c01,'mae',distribution,alpha,beta);
[lambda,Dmbre] = highrate(K,p0,mu,sigma,c10,c01,'mbre',distribution,alpha,beta);

%Figure 10
figure;
plot(p0,betapdf(p0,alpha,beta),'k');
hx = xlabel('$p_0$','Interpreter','latex','FontSize',28);
hy = ylabel('$f_{P_0}(p_0)$','Interpreter','latex','FontSize',28);
set(gca,'FontName','Times New Roman','FontSize',28);

%Figure 11
figure;
hp = semilogy(1:KK,D_mae,'k*:',1:KK,D_mbre,'ko-');
hx = xlabel('$K$','Interpreter','latex','FontSize',28);
hy = ylabel('$D$','Interpreter','latex','FontSize',28);
set(gca,'FontName','Times New Roman','FontSize',28);
set(hp,'MarkerSize',18);
axis([0 9 .0005 .04]);

%Figure 12
figure;
semilogy(R,Dmbre,'k-',R,Dmae,'k:');
ylabel('$D$','Interpreter','latex','FontSize',28);
xlabel('$R$ (bits)','Interpreter','latex','FontSize',28);
set(gca,'FontSize',28,'FontName','Times New Roman');

%Figure 13
figure;
plot(p0,lambda,'k');
xlabel('$p_0$','Interpreter','latex','FontSize',28);
ylabel('$\lambda(p_0)$','Interpreter','latex','FontSize',28);
set(gca,'FontSize',28,'FontName','Times New Roman');

%Figure 14
KK = 4;
for K = 1:KK
    figure; 
    hp = plot(p0,J,'k');
    set(hp,'LineWidth',1.5,'Color',[0.5 0.5 0.5]);
    hold on;
    
    a = amae{K};
    b = bmae{K};
    for jj = 1:K
        p0t = [b(jj),b(jj+1)];
        Jtilde = c10*p0t.*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-p0t).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj)))));
        hp = plot(p0t,Jtilde,'k:',a(jj),c10*a(jj).*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-a(jj)).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))),'k*');
        set(hp,'LineWidth',1.5,'MarkerSize',36);
    end
    
    a = ambre{K};
    b = bmbre{K};
    for jj = 1:K
        p0t = [b(jj),b(jj+1)];
        Jtilde = c10*p0t.*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-p0t).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj)))));
        hp = plot(p0t,Jtilde,'k-',a(jj),c10*a(jj).*Qfn(mu/(2*sigma) + sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))) + c01*(1-a(jj)).*Qfn(mu/(2*sigma) - sigma/mu*log(c10*a(jj)./(c01*(1-a(jj))))),'ko');
        set(hp,'LineWidth',1.5,'MarkerSize',36);
    end
    hx = xlabel('$p_0$','Interpreter','latex','FontSize',56);
    hy = ylabel('$\tilde{J}(p_0,v(p_0))$','Interpreter','latex','FontSize',56);
    set(gca,'FontName','Times New Roman','FontSize',56);
end
