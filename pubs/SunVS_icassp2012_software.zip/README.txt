COLLABORATIVE KALMAN FILTERING TESTBENCH
(C) John Z. Sun, Kush R. Varshney, Karthik Subbian, and Dhruv Parthasarathy
Contact John Z. Sun (johnsun@mit.edu) for questions.

This testbench can be used for exploratory purposes without permission.
For use in work to be published or for commercial use, please contact John Z. Sun.

Implements http://arxiv.org/abs/1110.2098 on a generative dataset matching the state space dynamics described in (2) and (3) of the paper. 


The files included are:
-----------------------
wrapper.m 		- main file
run_CKF_EM.m		- runs EM learning algorithm
run_CKF_nUsers.m	- wrapper for the n-user Kalman filter
run_CKF_nFBKF.m		- forward/backward algorithm to implement Kalman filter/smoother
plot_Results.m		- plot testbench results
generate_CKF_data.m	- generate data used in testbench - output to data_CKF_test


Main instructions:
------------------
1. Run generate_CKF_data.m to create dataset based on state space model for parameters that the user specifies.  
	This generates both a true preference tensor as well as a training set of observed preferences. 
	The resulting parameters and preferences are saved to data_CKF_test
2. Run wrapper.m to implement learning and a baseline comparison.
	1) Loads data, user specifies what parameters are unknown
	2) Runs a baseline test of estimating user factor tensor assuming all model parameters and item factor matrix 			is known.  This is a lower bound for the achievable prediction performance.
	3) Runs EM algorithm to learn both model parameters, item factor matrix and user factor tensor. 
	4) Plot comparison between actual prediction performance and baseline. 

WARNING:
This code uses some functions that may not appear in older versions of MATLAB.  Commented code using deprecated notation exists that can replace the potentially problematic lines. 