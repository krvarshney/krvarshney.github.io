% PLOT_RESULTS - plot results comparing EM prediction versus baseline
%
% Syntax: plot_Results(p_vec, iter, xKAL_learn, xRTS_learn, xKAL_base, xRTS_base)
%
% Inputs:
%    p_vec          - array of parameters for each iteration
%    iter           - # runs of learning
%    xKAL_learn     - Kalman filter output for each iteration
%    xRTS_learn     - Kalman smoother output for each iteration
%    xKAL_base      - Kalman filter baseline 
%    xRTS_base      - Kalman smoother baseline
%
% Outputs:
%    Figures
%
%
% Author: John Z. Sun
% IBM/MIT
% email: johnsun@mit.edu
% Aug 2011; Last revision: 10-31-2012

%------------- BEGIN CODE --------------


function plot_Results(p_vec, iter, xKAL_learn, xRTS_learn, xKAL_base, xRTS_base)

    close all

    % find true data to compare to
    load data_CKF_test
    

    % storage of learned parameters
    rmseVarU_learn = zeros(iter+1,1);
    rmseVarQ_learn = zeros(iter+1,1);
    rmseVarR_learn = zeros(iter+1,1);
    rmseA_learn = zeros(iter+1,1);
    rmseH_learn = zeros(iter+1,1);
    for i = 1:iter+1
        rmseVarU_learn(i) = myRMSE(varU - p_vec(i).CovX{1}(1));
        rmseVarQ_learn(i) = myRMSE(varQ - p_vec(i).varQ);
        rmseVarR_learn(i) = myRMSE(varR - p_vec(i).varR);
        rmseA_learn(i) = myRMSE(A - p_vec(i).A);
        rmseH_learn(i) = myRMSE(V - p_vec(i).V);
    end
    

    % get baseline results
    U_kal_base = zeros(N,K,T);
    U_rts_base = zeros(N,K,T);
    Yhat_kal_base = zeros(M,N,T);
    Yhat_rts_base = zeros(M,N,T);
    
    % get user factors from baseline Kalman estimates
    for n = 1:N
        U_kal_base(n,:,:) = reshape(xKAL_base{n}, 1, K, T);
        U_rts_base(n,:,:) = reshape(xRTS_base{n}, 1, K, T);
    end
    for t = 1:T
        % predict observation matrix
        Yhat_kal_base(:,:,t) = V * U_kal_base(:,:,t)';
        Yhat_rts_base(:,:,t) = V * U_rts_base(:,:,t)';
    end
    % find RMSE of user factors
    rmseU_kal_base = myRMSE(U_kal_base - Ut);
    rmseU_rts_base = myRMSE(U_rts_base - Ut);
    % find RMSE of predictions
    rmseY_kal_base = myRMSE(Yhat_kal_base - Ytrue);
    rmseY_rts_base = myRMSE(Yhat_rts_base - Ytrue);
    % set baseline of a priori prediction
    
    
    % get learned results
    rmseU_kal_learn = zeros(iter,1);
    rmseU_rts_learn = zeros(iter,1);
    rmseY_kal_learn = zeros(iter,1);
    rmseY_rts_learn = zeros(iter,1);
    
    for i = 1:iter
        % learned user factors
        U_kal_learn = xKAL_learn{i};
        U_rts_learn = xRTS_learn{i};
        Yhat_kal_learn = zeros(M,N,T);
        Yhat_rts_learn = zeros(M,N,T);
        for t = 1:T
            % predict observation matrix
            Yhat_kal_learn(:,:,t) = p_vec(i).V * U_kal_learn(:,:,t)';
            Yhat_rts_learn(:,:,t) = p_vec(i).V * U_rts_learn(:,:,t)';
        end 
        % find RMSE of user factors
        rmseU_kal_learn(i) = myRMSE(U_kal_learn - Ut);
        rmseU_rts_learn(i) = myRMSE(U_rts_learn - Ut);
        % find RMSE of predictions
        rmseY_kal_learn(i) = myRMSE(Yhat_kal_learn - Ytrue);
        rmseY_rts_learn(i) = myRMSE(Yhat_rts_learn - Ytrue);
    end


    % plot specifications
    disp('Start plotting')
    lineWidth = 4;
    fontsize = 15;
    ColorSet = [0,0,0; ...
                255,0,0; ...
                0,0,255; ...
                0,180,0; ...
                255,150,50] / 255;
            
    
    % plot parameter prediction
    figure('Position', [100 100 600 500], 'Color', 'w');
    hold all
    plot(0:iter, rmseVarU_learn, '-x', 'LineWidth',lineWidth, 'Color', ColorSet(1,:))
    plot(0:iter, rmseVarQ_learn, '-o', 'LineWidth',lineWidth, 'Color', ColorSet(2,:))
    plot(0:iter, rmseVarR_learn, '-+', 'LineWidth',lineWidth, 'Color', ColorSet(3,:))
    plot(0:iter, rmseA_learn, '-d', 'LineWidth',lineWidth, 'Color', ColorSet(4,:))
    plot(0:iter, rmseH_learn, '-p', 'LineWidth',lineWidth, 'Color', ColorSet(5,:))
    legend('varU', 'varQ', 'varR', 'A', 'H', 'Location', 'best')
    set( gca, 'FontSize', fontsize )
    xlabel('Iteration')
    ylabel('RMSE')
    title('Parameter Prediction')
    axis([0 15 0 0.6])
    
    
    % plot user factor prediction
    figure('Position', [100 100 600 500], 'Color', 'w');
    hold all
    plot(1:iter, rmseU_kal_base*ones(iter,1), '--', 'LineWidth',lineWidth, 'Color', ColorSet(1,:))
    plot(1:iter, rmseU_rts_base*ones(iter,1), '--', 'LineWidth',lineWidth, 'Color', ColorSet(2,:))
    plot(1:iter, rmseU_kal_learn, '--', 'LineWidth',lineWidth, 'Color', ColorSet(1,:))
    plot(1:iter, rmseU_rts_learn, '-', 'LineWidth',lineWidth, 'Color', ColorSet(2,:))    
    set( gca, 'FontSize', fontsize )
    xlabel('Iteration')
    ylabel('RMSE')
    legend('Filter baseline','Smoother baseline','Filter learn', 'Smoother learn', 'Location', 'best')
    title('User Factor Prediction')
    axis([0 iter 0 .8])
    
    
    % plot preference prediction
    figure('Position', [100 100 600 500], 'Color', 'w');
    hold all
    plot(1:iter, rmseY_kal_base*ones(iter,1), '--', 'LineWidth',lineWidth, 'Color', ColorSet(1,:))
    plot(1:iter, rmseY_rts_base*ones(iter,1), '--', 'LineWidth',lineWidth, 'Color', ColorSet(2,:))
    plot(1:iter, rmseY_kal_learn, '--', 'LineWidth',lineWidth, 'Color', ColorSet(1,:))
    plot(1:iter, rmseY_rts_learn, '-', 'LineWidth',lineWidth, 'Color', ColorSet(2,:))    
    set( gca, 'FontSize', fontsize )
    xlabel('Iteration')
    ylabel('RMSE')
    legend('Filter baseline','Smoother baseline','Filter learn', 'Smoother learn', 'Location', 'best')
    title('Preference Estimation')
    axis([0 iter 0 1.5])
end



% get rmse for matrix
function out = myRMSE( in )
    out = sqrt(sum(in(:).^2)/length(in(:)));
end

%------------- END OF CODE --------------
