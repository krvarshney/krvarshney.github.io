%%% wrapper for learning for CKF -- implements http://arxiv.org/abs/1110.2098
% Procedure is as follows
%   1) Generate model data
%   2) Run CKF on true parameters to set baseline
%   3) Perform learning and CKF estimation concurrently
%   4) Process and display results
%
%
% Author: John Z. Sun
% IBM/MIT
% email: johnsun@mit.edu
% Aug 2011; Last revision: 10-31-2012

%------------- BEGIN CODE --------------

%% clear workspace
% clc
% close all
% clear all
    

%% load data
disp('Load data')
load data_CKF_test


%% run CKF estimation on true parameters for baseline comparison

% specify struct of Kalman filter parameters
p_init.K = K;                           % # factors
p_init.M = M;                           % # items
p_init.N = N;                           % # users
p_init.T = T;                           % # time slots
p_init.varU = varU;                     % variance of U 
p_init.varV = varV;                     % variance of H (or V)
p_init.varQ = varQ;                     % variance of process noise
p_init.varR = varR;                     % variance of measurement noise
p_init.A = A;                           % true A matrix
p_init.V = V;                           % true V matrix
p_init.mu = cell(N,1);                  % a priori init state
p_init.CovX = cell(N,1);                % a priori covariance
p_init.At = cell(T,N);                  % time-dependent process transformation
p_init.Ht = cell(T,N);                  % time-dependent measurement
Y = cell(N,T);                          % observations at each time for user n
for n = 1:N
    p_init.mu{n} = zeros(K,1);          
    p_init.CovX{n} = varU*eye(K);       
    for t = 1:T
        p_init.At{t,n} = A;
        p_init.Ht{t,n} = V(obsTensor(:,n,t),:);
        Y{t,n} = Yobserved(obsTensor(:,n,t),n,t);
    end
end

disp('Run baseline estimation assuming true parameters known')
[~,~,xKAL_base xRTS_base] = run_CKF_nUsers(p_init, Y);
% [temp1,temp1,xKAL_base xRTS_base] = run_CKF_nUsers(p_init, Y);                % <-- deprecated notation
disp('Baselines saved')
    
    

%%  if learning, guess parameters
disp('Guess parameters')
learnP.CovX = 1;            % learn a priori covariance?                        % <--- specify what parameters to learn
learnP.varQ = 1;            % learn process noise variance?
learnP.varR = 1;            % learn measurement noise variance?
learnP.A = 1;               % learn process?
learnP.V = 1;               % learn item factors?

% if learning, change parameters to these                                       % <--- guess parameters
if learnP.A
    Aest = .7*A + .3*randn(K);
    p_init.A = Aest;
end

if learnP.V
    Vest = .8*V + .2*randn(M,K);
    p_init.V = Vest;
end

for n = 1:N
    if learnP.CovX
        p_init.CovX{n} = .8*eye(K);
    end
    for t = 1:T
        if learnP.A
            p_init.At{t,n} = Aest;
        end
        if learnP.V
            p_init.Ht{t,n} = Vest(obsTensor(:,n,t),:);
        end
    end
end
if learnP.varQ
    p_init.varQ = 0.15;
end
if learnP.varR
    p_init.varR = 0.25;
end

    
%% run Expectation-Maximization learning algorithm and predictor
disp('Run CKF learning algorithm')
iter = 10;                                                                      %  <--- specify # of iterations

% p_vec is parameters for each iteration (M-step)
% loglike is log likelihood of innovation
% xKAL_learn is result from Kalman filter for each iteration (E-step)
% xRTS_learn is result from Kalman smoother for each iteration (E-step)
[p_vec loglike xKAL_learn xRTS_learn] = run_CKF_EM(p_init, Y, iter, obsTensor, learnP);


%% plot results
disp('Plot results')
plot_Results(p_vec, iter, xKAL_learn, xRTS_learn, xKAL_base, xRTS_base);
disp('Finished plots')


%% end simulation
disp('End...')

%------------- END OF CODE --------------